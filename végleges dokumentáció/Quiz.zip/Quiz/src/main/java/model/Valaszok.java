package model;

public class Valaszok {
    /*CREATE TABLE valaszok (
    valasz_id NUMBER(10) PRIMARY KEY,
    kerdes_id NUMBER(10) NOT NULL, -- a hozzá tartozó kérdés azonosítója
    valasz_szoveg VARCHAR2(200) NOT NULL,
    helyes_e INTEGER NOT NULL,  -- 0 ha rossz a válasz, 1 ha jó a válasz
    FOREIGN KEY (kerdes_id) REFERENCES kerdesek(kerdes_id) --
);*/
    private int id;
    private int kerdes_id;
    private String szoveg;
    private boolean helyes_e;
}
