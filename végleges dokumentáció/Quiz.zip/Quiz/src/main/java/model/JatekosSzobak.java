package model;

public class JatekosSzobak {
}
