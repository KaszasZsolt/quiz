package controller;

import javafx.fxml.FXML;

import java.io.IOException;
import java.util.List;

public class RegisterController {

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }

    @FXML
    private void toRegister() throws IOException {

        App.setRoot("primary");
    }

    /*public void setContact(Contact c) {
        this.contact = c;
        List<Phone> phones = phoneDao.findAllByContactId(c);
        contact.setPhones(phones);

        name.setText(contact.getName());
        email.setText(contact.getEmail());
        address.setText(contact.getAddress());
        company.setText(contact.getCompany());
        position.setText(contact.getPosition());
        birth.valueProperty().set(contact.getDateOfBirth());
        numbers.getItems().setAll(phones);
    }*/
}
