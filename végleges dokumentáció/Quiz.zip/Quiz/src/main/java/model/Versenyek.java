package model;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

@ToString
@NoArgsConstructor
@Getter @Setter
public class Versenyek implements Serializable{
    /*versenyek : Ez a tábla a versenyek adatait tárolja, azokat az eseményeket, amelyeken a felhasználók részt vehetnek.

    CREATE TABLE versenyek (
id NUMBER PRIMARY KEY, -- egyedi azonosító
datum DATE NOT NULL, -- a verseny dátuma
idopont TIMESTAMP NOT NULL, -- a verseny kezdési időpontja
felhasznalok_id NUMBER NOT NULL, -- a résztvevők azonosítói
tema CHAR(255) NOT NULL, -- a verseny témája
FOREIGN KEY (felhasznalok_id) REFERENCES felhasznalok(felhasznalo_id) -- idegen kulcs a felhasznalok táblára
);*/
    private int verseny_id;
    private int felhasznalok_id;
    private String tema;
    private LocalDate datum;
    private LocalTime idopont;
}



       /* kerdesek: Ez az adattábla tárolja az összes kérdést, amelyek az alkalmazásban megjelennek.
        valaszok : Ez az adattábla tartalmazza az összes választ, amelyeket a felhasználók az egyes kérdésekre adhatnak
        jatekosszobak: Ez az adattábla tartalmazza az összes játékos szobát az alkalmazásban.
        versenyek : Ez a tábla a versenyek adatait tárolja, azokat az eseményeket, amelyeken a felhasználók részt vehetnek.
        forumposztok : Ez a tábla a fórumposztok adatait tárolja, amelyek a felhasználók által létrehozott bejegyzések a fórumon.

        */