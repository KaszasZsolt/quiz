package model;

public class ForumPosztok {
}
