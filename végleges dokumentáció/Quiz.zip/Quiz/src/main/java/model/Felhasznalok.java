package model;

import java.time.LocalDate;
import java.util.List;

public class Felhasznalok {
    /*CREATE TABLE felhasznalok (
            felhasznalo_id NUMBER(10) PRIMARY KEY, -- elsődleges kulcs
    email VARCHAR2(50) NOT NULL, -- a felhasználó e-mail címe
    felhasznalonev VARCHAR2(50) NOT NULL, -- belépési név
    jelszo VARCHAR2(50) NOT NULL, -- jelszó
    admin INTEGER DEFAULT 0, -- 0: mezei játékos, 1: rendszergazda, 2: adminisztrátor
    reg_datum DATE NOT NULL, -- a regisztráció dátuma
    pontszam NUMBER(10) DEFAULT 0 -- a meccsek során szerzett pontok összege
);*/
    private int id;
    private String felhasznalonev;
    private String email;
    private String jelszo;
    private int rang;
    private LocalDate regisztracio;
    private int pontszam;
}
