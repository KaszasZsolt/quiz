package model;

public class Kerdesek {
/*CREATE TABLE kerdesek (
    kerdes_id NUMBER(10) PRIMARY KEY,
    kerdes_szoveg VARCHAR2(200) NOT NULL,
    nehezseg INTEGER NOT NULL, -- 0-tól 5-ig különböző nehézségű szintek
    kategoria VARCHAR2(50) NOT NULL -- témakőr amibe a kérdés tartozik (történelem,matematika, stb...)
);
*/
    private int id;
    private String szoveg;
    private int nehezseg;
    private String kategoria;
}
