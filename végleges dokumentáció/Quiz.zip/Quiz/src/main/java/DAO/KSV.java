package DAO;

public interface KSV {
}
