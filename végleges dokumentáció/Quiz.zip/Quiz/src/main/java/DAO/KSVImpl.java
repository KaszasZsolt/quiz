package DAO;

public class KSVImpl {
    KSVImpl () {

    }
}
