package controller;

import utils.ConnectionUtil;
import static utils.SqlUtil.*;
import java.sql.*;

public class DBController {

    private Connection conn = null;
    private String connectionURL = ConnectionUtil.getValue("db.url");

    public DBController() {
        try {
            conn = DriverManager.getConnection(connectionURL);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void getAllQuestionsAndResponses() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet qs = stmt.executeQuery(SELECT_ALL_KERDESEK);
            ResultSet rs = stmt.executeQuery(SELECT_ALL_VALASZOK);
            // további műveletek a ResultSet objektummal
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void ujFelhasznalo() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet fh = stmt.executeQuery(SELECT_ALL_FEHASZNALOK);
            // további műveletek a ResultSet objektummal
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
